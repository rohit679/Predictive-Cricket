#***************************Modules********************************** 

from random import *   
import os

#********************Defining all the game related function********************

def play(over,target):
    good_wishes=["Remarkable Shot!!","^^Oh my goodness that's really awesome shot^^","There was no chance for any fielder",\
                 "***Classical shot***","Finds the boundary easily","Great playing:)"]
    suggession=["Need to play with more focus","Great bowling,No chance for batsman!",\
                "The bowler is clever not let the batsman do anything","Fully dominating bowling by the bowler!!!"]
    wicket_left=10
    run=0
    ball_left=over*6
    while(ball_left>0 and wicket_left>0 and run<target): 
        ch=int(input("Enter your choice(1-50)"))
        x=randint(1,50)   #for computer generated number
        if abs(x-ch)<5:   #if the difference among computer and you was in the range 0-4 then it's 6 
            print("WOW it's 6\nExtra ordinary prediction:)")
            print(choice(good_wishes))
            run+=6
            ball_left-=1
        if abs(x-ch)>=5 and abs(x-ch)<10:  #if the difference among computer and you was in the range 5-9 then it's 4 
            print("Great it's a bounadary\nRemarkable prediction:)")
            print(choice(good_wishes))
            run+=4
            ball_left-=1
        if abs(x-ch)>=10 and abs(x-ch)<15:  #if the difference among computer and you was in the range 10-14 then it's 3 
            print("Scored 3 runs!!\nJust missed by the boundary")
            run+=3
            ball_left-=1
        if abs(x-ch)>=15 and abs(x-ch)<20:  #if the difference among computer and you was in the range 15-19 then it's 2 
            print("Good running between the wicket\nscored 2 runs")
            run+=2
            ball_left-=1
        if abs(x-ch)>=20 and abs(x-ch)<25:  #if the difference among computer and you was in the range 20-24 then it's 1 
            print("A sparkle running for single\nscored 1 run")
            run+=1
            ball_left-=1
        if abs(x-ch)>=25 and abs(x-ch)<30:  #if the difference among computer and you was in the range 25-29 then it's 0 
            print("oops!!! DOT BALL\nPlay carefully:)")
            ball_left-=1
        if abs(x-ch)>=30:  #if the difference among computer and you was equal or greater than 30 then it's wicket 
            print(choice(suggession))
            wicket_left-=1
            ball_left-=1
        print("TOTAL RUNS:",run)
        print("BALLS LEFT:",ball_left)
        print("WICKET LEFT",wicket_left)
    if(wicket_left==0 and run<target):    #if all out condition
        print("All out!!!")
        print("Your score:",run)
        print("YOU LOOSE\nplease try again")
    elif(ball_left==0 and run<target):    #if there will no ball remained
        print("Total over completed")
        print("Your score:",run)
        print("YOU LOOSE\nplease try again")
    elif(run>=target):     #if your run is greater or equal to target
        print("WOW you won the match by ",wicket_left," wickets")
        print("Your score:",run)
        f=open('highest_run.txt')  #Reading the written high score of file 
        p=f.read()    
        f.close()
        if(run>int(p)):  #checking current run with file run,if it current run is greater then go and write
            f=open('highest_run.txt','w')
            p=f.write(str(run))
            f.close()
    input("\n\nPress enter to go back:")  #for go back to the front page
    gameloop()
def highest_run():   #checking the highest run
    f=open('highest_run.txt')
    p=f.read()
    f.close()
    print("HIGHEST RUN SCORED:",int(p))
    input("\n\nPress enter to go back:")
    gameloop()
    
def rules():   #rules for the game
    print("Rules:\n1.This is a simple predictive cricket game.2.In this game you have to predict a number between 1 to 50")
    print("3.If your prediction is closure to 5 consecutive number to the computer generated number, then you will get 6 runs")
    print("4.If your prediction is between 5 to 10 consecutive numbers to the computer generated number, then you will get 4 runs")
    print("5.If your prediction is between 10 to 15 consecutive numbers to the computer generated number, then you will get 3 runs")
    print("6.If your prediction is between 15 to 20 consecutive numbers to the computer generated number, then you will get 2 runs")
    print("7.If your prediction is between 20 to 25 consecutive numbers to the computer generated number, then you will get 1 runs")
    print("8.If your prediction is between 25 to 30 consecutive numbers to the computer generated number, then you will get 0 runs")
    print("9.If your prediction is over 30 consecutive numbers to the computer generated number, then you will out")
    print("10.The computer generated number is the randomly generated number by computer")
    input("\n\nPress enter to go back:")
    gameloop()

        
#************************Mainloop************************            
        

def gameloop():  #main loop of the game/front page
    while(1):    #infinite loop
        print("\nWelcome to Python cricket!!!")
        print("1.Play cricket\n2.Highest run\n3.Rules\n4.exit")  #options
        x=int(input("Enter your choice(1-4):")) #your choice
        if(x==1):
            over=int(input("Enter how many overs you want to play:"))  
            target=int(input("Enter you target that you to achieve:"))
            play(over,target)  #calling play function by passing over and target to it.
        elif(x==2):
            highest_run()    #checking highest run
        elif(x==3):
            rules()          #checking rules 
        elif(x==4):          #for exit the game
            exit(0);
        else:
            print("Invalid choice\nplease try again")  #for invalid choice

#*********************calling mainloop***********************

if(not os.path.exists("highest_run.txt")):    #if highest_run file is not there then create that and store 0 to it.
    with open("highest_run.txt", "w") as f:
        f.write("0")
gameloop()     #calling mainloop   
